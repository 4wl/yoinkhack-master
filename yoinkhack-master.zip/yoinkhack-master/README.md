## Strong people
darki<br>
neko<br>
praam<br>
69hr<br>
aluminisin<br>
i am become death<br>
mikk<br>
plivid<br>
tbm<br>
b0ba<br>
dacha<br>
svintus<br>
daisy<br>
and more i might have forgot
