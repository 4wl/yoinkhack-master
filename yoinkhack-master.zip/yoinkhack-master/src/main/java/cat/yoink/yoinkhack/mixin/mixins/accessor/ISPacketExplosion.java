package cat.yoink.yoinkhack.mixin.mixins.accessor;

public interface ISPacketExplosion
{
	float getMotionX();

	void setMotionX(float x);

	float getMotionY();

	void setMotionY(float y);

	float getMotionZ();

	void setMotionZ(float z);
}
