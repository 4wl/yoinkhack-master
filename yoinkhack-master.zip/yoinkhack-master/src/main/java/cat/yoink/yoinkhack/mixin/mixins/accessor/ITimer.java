package cat.yoink.yoinkhack.mixin.mixins.accessor;

public interface ITimer
{
	float getTickLength();

	void setTickLength(float length);
}
