package cat.yoink.yoinkhack.impl.module.hud;

import cat.yoink.yoinkhack.api.module.Category;
import cat.yoink.yoinkhack.api.module.Module;

public class CustomFont extends Module
{
	public CustomFont(String name, Category category, String description)
	{
		super(name, category, description);
	}
}
