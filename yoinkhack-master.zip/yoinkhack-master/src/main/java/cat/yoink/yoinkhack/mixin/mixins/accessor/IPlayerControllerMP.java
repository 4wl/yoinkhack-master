package cat.yoink.yoinkhack.mixin.mixins.accessor;

public interface IPlayerControllerMP
{
	boolean isHittingBlock();
}
