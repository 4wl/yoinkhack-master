package cat.yoink.yoinkhack.mixin.mixins.accessor;

public interface ISPacketPlayerPosLook
{
	float getYaw();

	void setYaw(float yaw);

	float getPitch();

	void setPitch(float pitch);
}
