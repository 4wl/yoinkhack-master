package cat.yoink.yoinkhack.mixin.mixins.accessor;

import net.minecraft.util.Timer;

public interface IMinecraft
{
	Timer getTimer();
}
